import React from 'react';
import StockSentimentAnalyzer from './SentimentPulse';

function App() {
  return <StockSentimentAnalyzer />;
}

export default App;
