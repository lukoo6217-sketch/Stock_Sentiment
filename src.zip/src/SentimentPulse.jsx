import React, { useState, useCallback } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell, PieChart, Pie, Legend } from 'recharts';

// Custom Word Cloud Component
const WordCloud = ({ words, colorScheme }) => {
  if (!words || words.length === 0) {
    return (
      <div className="flex items-center justify-center h-48 text-zinc-500 italic">
        No words to display
      </div>
    );
  }

  const maxCount = Math.max(...words.map(w => w.count));
  const minCount = Math.min(...words.map(w => w.count));
  
  const getSize = (count) => {
    const normalized = maxCount === minCount ? 0.5 : (count - minCount) / (maxCount - minCount);
    return 14 + normalized * 28;
  };

  const getOpacity = (count) => {
    const normalized = maxCount === minCount ? 0.8 : (count - minCount) / (maxCount - minCount);
    return 0.5 + normalized * 0.5;
  };

  return (
    <div className="flex flex-wrap gap-3 justify-center items-center p-6 min-h-[200px]">
      {words.slice(0, 40).map((item, idx) => (
        <span
          key={idx}
          className="cursor-default transition-all duration-200 hover:scale-110"
          style={{
            fontSize: `${getSize(item.count)}px`,
            color: colorScheme,
            opacity: getOpacity(item.count),
            fontWeight: item.count > (maxCount * 0.7) ? 700 : 500,
          }}
        >
          {item.word}
        </span>
      ))}
    </div>
  );
};

// Sentiment Badge Component
const SentimentBadge = ({ sentiment }) => {
  const styles = {
    positive: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    neutral: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
    negative: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
  };
  
  return (
    <span className={`px-2 py-0.5 text-xs font-medium rounded border ${styles[sentiment]}`}>
      {sentiment}
    </span>
  );
};

// Stats Card Component
const StatsCard = ({ label, value, subvalue, color }) => (
  <div className="relative overflow-hidden rounded-xl bg-zinc-900/50 border border-zinc-800 p-5">
    <div className="absolute top-0 right-0 w-20 h-20 rounded-full blur-3xl opacity-20" style={{ backgroundColor: color }} />
    <p className="text-zinc-500 text-sm font-medium tracking-wide uppercase">{label}</p>
    <p className="text-3xl font-bold mt-1" style={{ color }}>{value}</p>
    {subvalue && <p className="text-zinc-500 text-sm mt-1">{subvalue}</p>}
  </div>
);

// Article Row Component
const ArticleRow = ({ article, index }) => (
  <div 
    className="group flex items-start gap-4 p-4 rounded-lg hover:bg-zinc-800/50 transition-all duration-200 border-b border-zinc-800/50 last:border-0"
    style={{ animationDelay: `${index * 30}ms` }}
  >
    <div className="flex-shrink-0 w-24 text-right">
      <p className="text-zinc-400 text-sm font-mono">{article.date}</p>
      <p className="text-zinc-600 text-xs font-mono">{article.time}</p>
    </div>
    <div className="flex-1 min-w-0">
      <a 
        href={article.link} 
        target="_blank" 
        rel="noopener noreferrer"
        className="text-zinc-200 hover:text-white transition-colors line-clamp-2 group-hover:underline underline-offset-2"
      >
        {article.title}
      </a>
    </div>
    <div className="flex-shrink-0 flex items-center gap-3">
      <span className={`font-mono text-sm ${
        article.compound > 0 ? 'text-emerald-400' : 
        article.compound < 0 ? 'text-rose-400' : 'text-amber-400'
      }`}>
        {article.compound > 0 ? '+' : ''}{article.compound.toFixed(3)}
      </span>
      <SentimentBadge sentiment={article.sentiment} />
    </div>
  </div>
);

// ============================================
// CONFIGURATION - Change this to your backend URL
// ============================================
const API_BASE_URL = 'http://localhost:8000';

// Main App Component
export default function StockSentimentAnalyzer() {
  const [ticker, setTicker] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [data, setData] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [sentimentFilter, setSentimentFilter] = useState('all');

  // Real API call to FastAPI backend
  const analyzeSentiment = useCallback(async () => {
    if (!ticker.trim()) {
      setError('Please enter a stock ticker symbol');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`${API_BASE_URL}/analyze`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ticker: ticker.toUpperCase().trim(),
          remove_stopwords: true,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.detail || `Failed to analyze ticker: ${response.status}`);
      }

      const result = await response.json();
      setData(result);
    } catch (err) {
      console.error('Analysis error:', err);
      
      // Check if it's a network error (backend not running)
      if (err.message.includes('Failed to fetch') || err.message.includes('NetworkError')) {
        setError(
          'Cannot connect to backend server. Please make sure the Python backend is running on http://localhost:8000'
        );
      } else {
        setError(err.message || 'An error occurred while analyzing the ticker');
      }
    } finally {
      setLoading(false);
    }
  }, [ticker]);

  const filteredArticles = data?.articles.filter(article => {
    const matchesKeyword = !searchKeyword || 
      article.title.toLowerCase().includes(searchKeyword.toLowerCase());
    const matchesSentiment = sentimentFilter === 'all' || 
      article.sentiment === sentimentFilter;
    return matchesKeyword && matchesSentiment;
  });

  const pieData = data ? [
    { name: 'Positive', value: data.stats.positive_count, color: '#10b981' },
    { name: 'Neutral', value: data.stats.neutral_count, color: '#f59e0b' },
    { name: 'Negative', value: data.stats.negative_count, color: '#f43f5e' },
  ] : [];

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      {/* Gradient Background */}
      <div className="fixed inset-0 bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950" />
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-900/10 via-transparent to-transparent" />
      
      {/* Grid Pattern Overlay */}
      <div 
        className="fixed inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                           linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
          backgroundSize: '60px 60px'
        }}
      />

      <div className="relative z-10">
        {/* Header */}
        <header className="border-b border-zinc-800/50 backdrop-blur-xl bg-zinc-950/50">
          <div className="max-w-7xl mx-auto px-6 py-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold tracking-tight">
                  <span className="text-emerald-400">Sentiment</span>
                  <span className="text-zinc-400">Pulse</span>
                </h1>
                <p className="text-zinc-500 text-sm mt-1">Real-time stock news sentiment analysis</p>
              </div>
              <div className="flex items-center gap-2 text-xs text-zinc-500">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                Powered by VADER NLP
              </div>
            </div>
          </div>
        </header>

        {/* Search Section */}
        <section className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex gap-4 items-end">
            <div className="flex-1 max-w-md">
              <label className="block text-zinc-400 text-sm font-medium mb-2">
                Stock Ticker Symbol
              </label>
              <input
                type="text"
                value={ticker}
                onChange={(e) => setTicker(e.target.value.toUpperCase())}
                onKeyDown={(e) => e.key === 'Enter' && analyzeSentiment()}
                placeholder="AAPL, TSLA, NVDA..."
                className="w-full px-4 py-3 bg-zinc-900 border border-zinc-700 rounded-lg text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all font-mono text-lg tracking-wider"
              />
            </div>
            <button
              onClick={analyzeSentiment}
              disabled={loading}
              className="px-8 py-3 bg-emerald-600 hover:bg-emerald-500 disabled:bg-zinc-700 disabled:cursor-not-allowed rounded-lg font-semibold transition-all duration-200 flex items-center gap-2"
            >
              {loading ? (
                <>
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Analyzing...
                </>
              ) : (
                <>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                  Analyze
                </>
              )}
            </button>
          </div>

          {error && (
            <div className="mt-4 p-4 bg-rose-500/10 border border-rose-500/30 rounded-lg text-rose-400">
              <p className="font-medium">Error</p>
              <p className="text-sm mt-1">{error}</p>
              {error.includes('backend') && (
                <p className="text-sm mt-2 text-zinc-400">
                  Run this command in PowerShell: <code className="bg-zinc-800 px-2 py-1 rounded">uvicorn main:app --reload --port 8000</code>
                </p>
              )}
            </div>
          )}
        </section>

        {/* Results Section */}
        {data && (
          <section className="max-w-7xl mx-auto px-6 pb-12">
            {/* Ticker Header */}
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-4xl font-bold tracking-tight">{data.ticker}</h2>
                <p className="text-zinc-500 mt-1">
                  {data.total_articles} articles analyzed • {data.stats.date_range.oldest} to {data.stats.date_range.newest}
                </p>
              </div>
              <div className={`text-5xl font-bold ${
                data.stats.avg_sentiment > 0 ? 'text-emerald-400' : 
                data.stats.avg_sentiment < 0 ? 'text-rose-400' : 'text-amber-400'
              }`}>
                {data.stats.avg_sentiment > 0 ? '+' : ''}{(data.stats.avg_sentiment * 100).toFixed(1)}
                <span className="text-lg text-zinc-500 ml-1">avg</span>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
              <StatsCard 
                label="Positive" 
                value={data.stats.positive_count} 
                subvalue={`${data.stats.positive_pct}%`}
                color="#10b981"
              />
              <StatsCard 
                label="Neutral" 
                value={data.stats.neutral_count} 
                subvalue={`${data.stats.neutral_pct}%`}
                color="#f59e0b"
              />
              <StatsCard 
                label="Negative" 
                value={data.stats.negative_count} 
                subvalue={`${data.stats.negative_pct}%`}
                color="#f43f5e"
              />
              <StatsCard 
                label="Total Articles" 
                value={data.total_articles}
                color="#8b5cf6"
              />
            </div>

            {/* Tabs */}
            <div className="flex gap-1 mb-6 bg-zinc-900/50 p-1 rounded-lg w-fit">
              {['overview', 'articles', 'wordclouds'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-all capitalize ${
                    activeTab === tab 
                      ? 'bg-zinc-700 text-white' 
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {tab === 'wordclouds' ? 'Word Clouds' : tab}
                </button>
              ))}
            </div>

            {/* Tab Content */}
            {activeTab === 'overview' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Sentiment Timeline */}
                <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-4">Sentiment Timeline</h3>
                  <ResponsiveContainer width="100%" height={280}>
                    <BarChart data={data.daily_averages}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                      <XAxis dataKey="date" tick={{ fill: '#71717a', fontSize: 12 }} tickLine={false} />
                      <YAxis domain={[-1, 1]} tick={{ fill: '#71717a', fontSize: 12 }} tickLine={false} />
                      <Tooltip
                        contentStyle={{ 
                          backgroundColor: '#18181b', 
                          border: '1px solid #3f3f46',
                          borderRadius: '8px'
                        }}
                        labelStyle={{ color: '#a1a1aa' }}
                      />
                      <Bar dataKey="average" radius={[4, 4, 0, 0]}>
                        {data.daily_averages.map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={entry.average > 0 ? '#10b981' : entry.average < 0 ? '#f43f5e' : '#f59e0b'}
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                {/* Sentiment Distribution */}
                <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6">
                  <h3 className="text-lg font-semibold mb-4">Sentiment Distribution</h3>
                  <ResponsiveContainer width="100%" height={280}>
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{ 
                          backgroundColor: '#18181b', 
                          border: '1px solid #3f3f46',
                          borderRadius: '8px'
                        }}
                      />
                      <Legend 
                        verticalAlign="bottom"
                        formatter={(value) => <span style={{ color: '#a1a1aa' }}>{value}</span>}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                {/* Trend Line */}
                <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6 lg:col-span-2">
                  <h3 className="text-lg font-semibold mb-4">Sentiment Trend</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={data.daily_averages}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                      <XAxis dataKey="date" tick={{ fill: '#71717a', fontSize: 12 }} tickLine={false} />
                      <YAxis domain={[-1, 1]} tick={{ fill: '#71717a', fontSize: 12 }} tickLine={false} />
                      <Tooltip
                        contentStyle={{ 
                          backgroundColor: '#18181b', 
                          border: '1px solid #3f3f46',
                          borderRadius: '8px'
                        }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="average" 
                        stroke="#10b981" 
                        strokeWidth={2}
                        dot={{ fill: '#10b981', strokeWidth: 0, r: 4 }}
                        activeDot={{ r: 6, fill: '#10b981' }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

            {activeTab === 'articles' && (
              <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl">
                {/* Search and Filter */}
                <div className="flex gap-4 p-4 border-b border-zinc-800">
                  <input
                    type="text"
                    value={searchKeyword}
                    onChange={(e) => setSearchKeyword(e.target.value)}
                    placeholder="Search articles..."
                    className="flex-1 px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  />
                  <select
                    value={sentimentFilter}
                    onChange={(e) => setSentimentFilter(e.target.value)}
                    className="px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
                  >
                    <option value="all">All Sentiments</option>
                    <option value="positive">Positive</option>
                    <option value="neutral">Neutral</option>
                    <option value="negative">Negative</option>
                  </select>
                </div>

                {/* Articles List */}
                <div className="max-h-[600px] overflow-y-auto">
                  {filteredArticles?.map((article, index) => (
                    <ArticleRow key={index} article={article} index={index} />
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'wordclouds' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <span className="w-3 h-3 rounded-full bg-emerald-500" />
                    <h3 className="text-lg font-semibold">Positive Words</h3>
                  </div>
                  <WordCloud words={data.word_frequencies.positive} colorScheme="#10b981" />
                </div>

                <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <span className="w-3 h-3 rounded-full bg-amber-500" />
                    <h3 className="text-lg font-semibold">Neutral Words</h3>
                  </div>
                  <WordCloud words={data.word_frequencies.neutral} colorScheme="#f59e0b" />
                </div>

                <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <span className="w-3 h-3 rounded-full bg-rose-500" />
                    <h3 className="text-lg font-semibold">Negative Words</h3>
                  </div>
                  <WordCloud words={data.word_frequencies.negative} colorScheme="#f43f5e" />
                </div>
              </div>
            )}
          </section>
        )}

        {/* Empty State */}
        {!data && !loading && (
          <section className="max-w-7xl mx-auto px-6 py-20">
            <div className="text-center">
              <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-zinc-900 flex items-center justify-center">
                <svg className="w-12 h-12 text-zinc-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-zinc-400 mb-2">Enter a ticker to begin</h3>
              <p className="text-zinc-600 max-w-md mx-auto">
                Analyze sentiment from the latest news headlines for any stock symbol. 
                Get insights into market perception through VADER sentiment analysis.
              </p>
              <div className="mt-6 p-4 bg-zinc-900/50 border border-zinc-800 rounded-lg max-w-md mx-auto">
                <p className="text-zinc-500 text-sm">
                  <span className="text-amber-400">⚠️ Backend Required:</span> Make sure the Python backend is running.
                </p>
                <code className="block mt-2 text-xs bg-zinc-800 p-2 rounded text-emerald-400">
                  uvicorn main:app --reload --port 8000
                </code>
              </div>
            </div>
          </section>
        )}

        {/* Footer */}
        <footer className="border-t border-zinc-800/50 mt-12">
          <div className="max-w-7xl mx-auto px-6 py-6">
            <p className="text-zinc-600 text-sm text-center">
              Disclaimer: This tool is for informational purposes only and should not be considered financial advice. 
              Sentiment analysis may not accurately reflect true market conditions.
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}
